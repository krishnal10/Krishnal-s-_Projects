package Collection_pro;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

class clction
{
	String a;
	String id,name,address,salary;
	
	ArrayList<String> list=new ArrayList<String>();
	Scanner s;
	


public void Show()
{
	s=	new Scanner(System.in);
	System.out.println("ENTER EMP ID :");
	id =s.nextLine();
	System.out.println("ENTER EMP NAME :");
	name = s.nextLine();
	System.out.println("ENTER SALARY :");
    salary =s.nextLine();
	System.out.println("ENTER ADRESS :");
    address =s.next();


    list.add(name);
    list.add(id);
    list.add(salary);
    list.add(address);

     
Iterator itr=list.iterator();
while(itr.hasNext()){  
System.out.println(itr.next());
}
}

 public void delete()
 {
	 String a;
	 s=	new Scanner(System.in);
System.out.println("ENTER FIELD NAME TO DELETE : ");
 a=s.nextLine();

    if(a.equals("name"))
      {
	     list.set(0,"" );
	    System.out.println("DELETED");
	   }

      else if(a.equals("id"))
     {
	list.set(1,"" );
	System.out.println("DELETED ");
     }
       else if(a.equals("salary"))
          {
	        list.set(2,"" );
	       System.out.println("DELETED");
          }

else if(a.equals("address"))
{
	list.set(3,"" );
	System.out.println("DELETED");
	
	
}
else
{
	System.out.println("WRONG SELECTION.....");
}

Iterator itr=list.iterator();
System.out.println("LIST AFTER DELETING "+a);
while(itr.hasNext()){  
System.out.println(itr.next());
}



      

}
 public void update()
 { String b,c;
	 s=	new Scanner(System.in);
System.out.println("ENTER FIELD TO BE UPDATED : ");
 b=s.nextLine();
 System.out.println("ENTER NEW VALUE FOR "+b+" : ");
 c=s.nextLine();
if(b.equals("name"))
{
	list.set(0,c );
	System.out.println("NAME UPDATED");
	
}


else if(b.equals("id"))
{
	list.set(1, c);
	System.out.println("ID UPDATED");
	
}


else if(b.equals("salary"))
{
	list.set(2, c);
	System.out.println("SALARY UPDATED");
	
}


else if(b.equals("address"))
{
	list.set(3, c);
	System.out.println("ADDRESS UPDATED");
	
	
}
else
{
	System.out.println("WRONG FIELD ENTERED...");
}

Iterator itr=list.iterator();
System.out.println("NEW LIST :->");
while(itr.hasNext()){  
System.out.println(itr.next());
}



}



}


public class collection {

	public static void main(String[] args) {
		
      clction c=new clction();
        c.Show();
        c.delete();
        c.update();

	}

}
