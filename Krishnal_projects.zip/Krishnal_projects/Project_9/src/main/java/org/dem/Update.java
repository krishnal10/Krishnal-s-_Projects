package org.dem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/update")
public class Update {
	@GET
	 @Path("{roll}")
	 public String getUpdate(@PathParam("roll") int roll)
	 {   Connection cn;
	    Statement st;
	    
	    try {
	    	 
	    	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	    	
	    	 
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			
			st=cn.createStatement();
			
			
			st.executeUpdate("update  pjct9 set city='Mumbai' where rollno="+roll);
			
			cn.commit();
			st.close();
			cn.close();
			
		} catch (Exception e) {
			System.out.println(e);
		}
		 return "Record Updated Sucessfully...";
	 }
}
