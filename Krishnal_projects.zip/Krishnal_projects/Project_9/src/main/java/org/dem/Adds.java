package org.dem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/add")
public class Adds {

	 @GET
	 @Path("{roll}/{name}/{age}/{city}")
	 public String getAdd(@PathParam("roll") int roll,@PathParam("name") String name,@PathParam("age") int age,@PathParam("city") String city)
	 {   Connection cn;
	    Statement st;
	    
	    try {
	    	 
	    	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	    	
	    	 
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			
			st=cn.createStatement();
			
			
			st.executeUpdate("insert into pjct9 values("+roll+",'"+name+"',"+age+",'"+city+"')");
			
			
			st.close();
			cn.close();
			
		} catch (Exception e) {
			System.out.println(e);
		}
		 return "Record Added Sucessfully...";
	 }
}
