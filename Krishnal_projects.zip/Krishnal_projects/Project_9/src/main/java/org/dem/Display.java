package org.dem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/display")
public class Display {
	@GET
	
	 public String getDisplay()
	 {  Connection cn;
	    Statement st;
	    ResultSet rs;
	    try {
	    	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	     cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
		  st=cn.createStatement();
		   rs=st.executeQuery("select * from pjct9");
		  
		   while(rs.next())
		   {   System.out.println();
			   System.out.print(rs.getInt("ROLLNO")+" "+rs.getString("NAME")+" "+rs.getInt("AGE")+" "+rs.getString("CITY"));
		   }
		  
			rs.close();
		   st.close();
			cn.close();
			
		} catch (Exception e) {
			
		}
		return "";
	 }
}
