package org.dem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/delete")
public class Delete {
	 @GET
	 @Path("{roll}")
	 public String getDelete(@PathParam("roll") int roll)
	 {   Connection cn;
	    Statement st;
	    
	    try {
	    	 
	    	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	    	
	    	 
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			
			st=cn.createStatement();
			
			
			st.executeUpdate("delete from pjct9 where rollno="+roll);
			
			cn.commit();
			st.close();
			cn.close();
			
		} catch (Exception e) {
			System.out.println(e);
		}
		 return "Record Deleted Sucessfully...";
	 }
}
