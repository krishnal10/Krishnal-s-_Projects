package org.dem;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Serv1
 */
@WebServlet("/Serv1")
public class Serv1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Serv1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 PrintWriter out=response.getWriter();
		    response.setContentType("text/html");
		    String name=request.getParameter("lb1");
		    int roll=Integer.parseInt(request.getParameter("lb2"));
		    int m1=Integer.parseInt(request.getParameter("lb3"));
		    int m2=Integer.parseInt(request.getParameter("lb4"));
		    int m3=Integer.parseInt(request.getParameter("lb5"));
		    int m4=Integer.parseInt(request.getParameter("lb6"));
		    int m5=Integer.parseInt(request.getParameter("lb7"));
		    double per=(m1+m2+m3+m4+m5)/5;
		    
		    Connection cn;
		    Statement st;
		    
		    try {
		    	 
		    	Class.forName("oracle.jdbc.driver.OracleDriver"); 
		    	
		    	
				cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
				
				
				st=cn.createStatement();
				request.setAttribute("name","DATA SAVED SUCCESSFULLY");
				st.executeUpdate("insert into result values("+roll+",'"+name+"',"+m1+","+m2+","+m3+","+m4+","+m5+")");
				st.executeUpdate("insert into results values("+roll+",'"+name+"',"+m1+","+m2+","+m3+","+m4+","+m5+","+per+")");
				RequestDispatcher rd=request.getRequestDispatcher("Insert.jsp");
				
				rd.forward(request, response);
				
				st.close();
				cn.close();
				out.close();
				
			} catch (Exception e) {
				System.out.println(e);
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
