package org.dem;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Serv3
 */
@WebServlet("/Serv3")
public class Serv3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Serv3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 PrintWriter out=response.getWriter();
		    response.setContentType("text/html");
		    int roll=Integer.parseInt(request.getParameter("nm"));
		    Connection cn;
		    Statement st;
		    ResultSet rs;
		    try {
		    	Class.forName("oracle.jdbc.driver.OracleDriver"); 
		    	
		    	
				cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
				
				
				st=cn.createStatement();
			
					
					 rs=st.executeQuery("select * from results where rollno="+roll);
					while(rs.next())
					{ 
						
					 float per=rs.getFloat(7);
					    String grade=" ";
					    String mess=" ";
					    if(per>90)
					    {
					    	grade="A";
					    	mess="CONGRATS";
					    }
					    if(per<90 && per>80)			    {
					    	grade="B";
					    	mess="CONGRATS";
					    }
					    if(per<80 && per>70)
					    {
					    	grade="C";
					    	mess="GOOD";
					    }
					    if(per<70)
					    {
					    	grade="FAIL";
					    	mess="WORK HARD";
					    }
					
					    
					   request.setAttribute("name",rs.getString(2));
					    request.setAttribute("r",roll);
					    request.setAttribute("p",per);
					    request.setAttribute("g",grade);
					    request.setAttribute("head",mess);
					    RequestDispatcher rd=request.getRequestDispatcher("Search.jsp");
					    rd.include(request, response);
					    rd.forward(request, response);
						rs.close();
					   st.close();
						cn.close();
						
					
							
						
				
					}
			   
			} catch (Exception e) {
				request.setAttribute("abc","RECORD NOT FOUND");
				 RequestDispatcher rd=request.getRequestDispatcher("Search.jsp");
				    rd.forward(request, response);
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
