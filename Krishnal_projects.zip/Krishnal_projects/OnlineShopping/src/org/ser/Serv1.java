package org.ser;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Serv1
 */
@WebServlet("/Serv1")
public class Serv1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Serv1() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String types=request.getParameter("lb1");
		String brand=request.getParameter("lb2");
		String model=request.getParameter("lb3");
		String ram=request.getParameter("lb4");
		String hd=request.getParameter("lb5");
		int price=Integer.parseInt(request.getParameter("lb6"));
		String color=request.getParameter("Color");
		int quantity=Integer.parseInt(request.getParameter("nm"));
		int pr=(price*quantity);
		double tax=(pr/10);
		double amt=(pr+tax);
		if(quantity < 1 )
		{
			out.print("QUANTITY CANNOT BE LESS THAN 1...");
		}
		else
		{
		RequestDispatcher rd;
		    request.setAttribute("type",types);
		    request.setAttribute("brand",brand);
		    request.setAttribute("model",model);
		    request.setAttribute("ram",ram);
		    request.setAttribute("hd",hd);
		    request.setAttribute("price",price);
		    request.setAttribute("color",color);
		    request.setAttribute("quant",quantity);
		    request.setAttribute("pr",pr);
		    request.setAttribute("tax",tax);
		    request.setAttribute("amt",amt);
		rd=request.getRequestDispatcher("Bill.jsp");
		rd.forward(request, response);
		}
		out.close();
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
