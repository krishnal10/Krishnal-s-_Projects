package org.ser;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Serv3
 */
@WebServlet("/Serv3")
public class Serv3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Serv3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		
		int price=Integer.parseInt(request.getParameter("t1"));
		int quantity=1;
		String type=" ";
		if(price == 7000)
		{
			 quantity=Integer.parseInt(request.getParameter("t6"));
			 type="CPU";
			
		}
		else if(price == 10000)
		{
			 quantity=Integer.parseInt(request.getParameter("t7"));
			 type="SMART WATCH";
		}
		else if(price == 300)
		{
			 quantity=Integer.parseInt(request.getParameter("t8"));
			 type="WIRELESS MOUSE";
		}
		else if(price == 1400)
		{
			 quantity=Integer.parseInt(request.getParameter("t9"));
			 type="EARBUDS";
		}
		
		
		
		int pr=(price*quantity);
		double tax=(pr/10);
		double amt=(pr+tax);
		
		if(quantity < 1 )
		{
			out.print("QUANTITY CANNOT BE LESS THAN 1...");
		}
		else
		{
		RequestDispatcher rd;
		   
		    request.setAttribute("price",price);
		    request.setAttribute("type",type);
		    request.setAttribute("quant",quantity);
		    request.setAttribute("pr",pr);
		    request.setAttribute("tax",tax);
		    request.setAttribute("amt",amt);
		rd=request.getRequestDispatcher("EBill.jsp");
		rd.forward(request, response);
		}
		out.print(price+"  "+quantity);
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
