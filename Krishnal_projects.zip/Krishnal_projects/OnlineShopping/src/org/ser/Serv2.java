package org.ser;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Serv2
 */
@WebServlet("/Serv2")
public class Serv2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Serv2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		
		int price=Integer.parseInt(request.getParameter("t1"));
		int quantity=1;
		String type=" ";
		if(price == 2200)
		{
			 quantity=Integer.parseInt(request.getParameter("t6"));
			 type="Jeans";
			
		}
		else if(price == 800)
		{
			 quantity=Integer.parseInt(request.getParameter("t7"));
			 type="T-shirt";
		}
		else if(price == 1200)
		{
			 quantity=Integer.parseInt(request.getParameter("t8"));
			 type="Top";
		}
		else if(price == 300)
		{
			 quantity=Integer.parseInt(request.getParameter("t9"));
			 type="Sando";
		}
		else if(price == 500)
		{
		    quantity=Integer.parseInt(request.getParameter("t10"));
			 type="Diaper";
		}
		
		
		int pr=(price*quantity);
		double tax=(pr/10);
		double amt=(pr+tax);
		
		if(quantity < 1 )
		{
			out.print("QUANTITY CANNOT BE LESS THAN 1...");
		}
		else
		{
		RequestDispatcher rd;
		   
		    request.setAttribute("price",price);
		    request.setAttribute("type",type);
		    request.setAttribute("quant",quantity);
		    request.setAttribute("pr",pr);
		    request.setAttribute("tax",tax);
		    request.setAttribute("amt",amt);
		rd=request.getRequestDispatcher("CBill.jsp");
		rd.forward(request, response);
		}
		out.print(price+"  "+quantity);
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
