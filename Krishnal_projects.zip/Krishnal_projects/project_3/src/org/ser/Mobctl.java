package org.ser;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Mobctl
 */
@WebServlet("/Mobctl")
public class Mobctl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Mobctl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 PrintWriter out=response.getWriter();
		    response.setContentType("text/html");
		    int sn=Integer.parseInt(request.getParameter("sn"));
		    String name=request.getParameter("nm");
		    Connection cn;
		    Statement st;
		    ResultSet rs;
		    try {
		    	Class.forName("oracle.jdbc.driver.OracleDriver"); 
		    	
		    	 
				cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
				
				
				st=cn.createStatement();
				
				
				st.executeUpdate("update diary set MOBILE='"+name+"' where SNO="+sn);
				out.print("<h1>DATA UPDATED SUCCESSFULLY</h1>");
				
			   st.close();
				cn.close();
				
			} catch (Exception e) {
				
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
