﻿Public Class Form2

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
       
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim a As String
        a = Form1.TextBox1.Text
        Label3.Text = a

        Dim b As String
        b = Form1.TextBox2.Text
        Label5.Text = b

        If (Form1.RadioButton1.Checked = True) Then
            Label7.Text = "MALE"
        ElseIf (Form1.RadioButton2.Checked = True) Then
            Label7.Text = "FEMALE"
      
        End If

        If (Form1.CheckBox1.Checked = True) Then
            Label9.Text = Label9.Text + "C++ "
        End If
        If (Form1.CheckBox2.Checked = True) Then
            Label9.Text = Label9.Text + " JAVA "
        End If
        If (Form1.CheckBox3.Checked = True) Then
            Label9.Text = Label9.Text + " HTML "
        End If


    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class